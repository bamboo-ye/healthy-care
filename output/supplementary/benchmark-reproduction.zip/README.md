# 记录采集组件实验复现

本包只含独立科研评分脚本、合成数据、冻结真实模型观测与运行证据。完整应用源码另见项目GitHub仓库。
Python 3.12标准库即可离线重算；无需模型密钥、SciencePal账号或再次调用供应商。

解压后进入本目录执行：

    python3 run_analysis.py health-research-input.json --out actual-output
    python3 unknown_sensitivity.py health-research-input.json --out actual-output/unknown-sensitivity.json

对比actual-output/report.json与reference/report.json、platform-evidence/report.json；整份JSON应一致。
敏感性分析与reference/unknown-sensitivity.json对比，属于事后分析，不替换主结果。
manifest.json保留原冻结材料哈希；SUPPLEMENT-MANIFEST.json校验本次全部补充文件。
数据集开发12/测试48，2类追问各一轮最多3字段。固定响应器、模板相关和未知编码等限制见protocol.md与结果说明。
SciencePal在该实验中评分既有模型观测，不是在平台运行OpenRouter采集。重算不是重新采集模型响应。
数据不含真实患者。主结果不能用作诊断或临床疗效指标。
